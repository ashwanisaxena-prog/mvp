package com.mvp.ai11;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ai11ApplicationTests {

	@Test
	void contextLoads() {
	}

}
